package nathanmerrell.com.moneymanagement

import android.os.Bundle
import android.support.v4.app.FragmentActivity
import android.support.v4.view.ViewPager
import kotlinx.android.synthetic.main.activity_archive_main.*
import nathanmerrell.com.moneymanagement.fragments.archiveFragment.ArchiveFragment
import nathanmerrell.com.moneymanagement.fragments.mainFragments.FragmentAdapter

class ArchiveActivity : FragmentActivity() {
    private lateinit var archiveFragment: ArchiveFragment
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_archive_main)

        archiveFragment = ArchiveFragment.newInstance()

        val viewPager: ViewPager = findViewById(R.id.pager)
        val adapter = FragmentAdapter(supportFragmentManager)

        adapter.addItem(0, archiveFragment)

        viewPager.offscreenPageLimit = 1
        viewPager.adapter = adapter

        archiveReturn.setOnClickListener {
            this.onBackPressed()
        }
    }
}