package nathanmerrell.com.moneymanagement.fragments.mainFragments

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import java.util.ArrayList

class FragmentAdapter(fm:FragmentManager):FragmentStatePagerAdapter(fm) {
    private val fragmentList = ArrayList<Fragment>()
    override fun getCount(): Int {
        return fragmentList.size
    }
    override fun getItem(position:Int):Fragment {
        return fragmentList[position]
    }
    fun addItem(position:Int, fragment:Fragment) {
        fragmentList.add(position, fragment)
    }
}
